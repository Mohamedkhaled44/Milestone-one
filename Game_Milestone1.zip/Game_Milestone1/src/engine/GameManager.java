package engine;

public interface GameManager {
		void startGame();
}
