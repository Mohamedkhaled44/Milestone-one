package engine.board;

public interface BoardManager {
	 int getSplitDistance();

}
